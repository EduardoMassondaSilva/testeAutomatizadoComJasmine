# testeAutomatizadoComJasmine
Introdução ao Jasmine para teste automatizado
